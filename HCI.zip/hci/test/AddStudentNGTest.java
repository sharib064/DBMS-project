/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author S
 */
public class AddStudentNGTest {
    
    public AddStudentNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of validation method, of class AddStudent.
     */
    @Test
    public void testValidation() {
        System.out.println("validation");
        String n = "";
        String fn = "";
        String nic = "";
        String b = "";
        String d = "";
        String roll = "";
        String pass = "";
        AddStudent instance = new AddStudent();
        boolean expResult = false;
        boolean result = instance.validation(n, fn, nic, b, d, roll, pass);
        assertEquals(result, expResult);
    }

    /**
     * Test of repeat method, of class AddStudent.
     */
    @Test
    public void testRepeat() {
        System.out.println("repeat");
        String name = "abc";
        String nic = "1234";
        String roll = "abc";
        AddStudent instance = new AddStudent();
        boolean expResult = false;
        boolean result = instance.repeat(name, nic, roll);
        assertEquals(result, expResult);
    }

    /**
     * Test of InsertIntoSql method, of class AddStudent.
     */
    @Test
    public void testInsertIntoSql() {
        System.out.println("InsertIntoSql");
        String name = "xyz";
        String fname = "xyz";
        String nic = "098765";
        String batch = "23";
        String depart = "se";
        String roll = "k8765";
        String pass = "1234";
        AddStudent instance = new AddStudent();
        boolean result =instance.InsertIntoSql(name, fname, nic, batch, depart, roll, pass);
        boolean expResult = true;
        assertEquals(result, expResult);
    }

    /**
     * Test of main method, of class AddStudent.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        AddStudent.main(args);
    }
    
}
