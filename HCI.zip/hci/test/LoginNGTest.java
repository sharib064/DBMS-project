/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author S
 */
public class LoginNGTest {
    
    public LoginNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of validation method, of class Login.
     */
    @Test
    public void testValidation() {
        System.out.println("validation");
        String username = "abc";
        String password = "123";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.validation(username, password);
        assertEquals(result, expResult);
    }

    /**
     * Test of InsertIntoSql method, of class Login.
     */
    @Test
    public void testInsertIntoSql() {
        System.out.println("InsertIntoSql");
        String username = "abc";
        String password = "123";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.InsertIntoSql(username, password);
        assertEquals(result, expResult);
    }

    /**
     * Test of main method, of class Login.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Login.main(args);
    }
    
}
