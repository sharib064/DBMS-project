import java.sql.*;
import javax.swing.JOptionPane;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author S
 */
public class AddMark extends javax.swing.JFrame {
    static String sel="k213889";
    boolean valid(){
        if(Float.valueOf(mid1.getText())>Float.valueOf(tmid1.getText())){
            JOptionPane.showMessageDialog(null, "mid 1 marks is higher than total");
            return false;
        }
        if(Float.valueOf(mid2.getText())>Float.valueOf(tmid2.getText())){
            JOptionPane.showMessageDialog(null, "mid 2 marks is higher than total");
            return false;
        }
        if(Float.valueOf(assig.getText())>Float.valueOf(tassig.getText())){
            JOptionPane.showMessageDialog(null, "assignment marks is higher than total");
            return false;
        }
        if(Float.valueOf(proj.getText())>Float.valueOf(tproj.getText())){
            JOptionPane.showMessageDialog(null, "project marks is higher than total");
            return false;
        }
        if(Float.valueOf(quiz.getText())>Float.valueOf(tquiz.getText())){
            JOptionPane.showMessageDialog(null, "quiz marks is higher than total");
            return false;
        }
        if(Float.valueOf(fnl.getText())>Float.valueOf(tfinal.getText())){
            JOptionPane.showMessageDialog(null, "final marks is higher than total");
            return false;
        }
        return true;
    }
    final void init(){
        try {
                Class.forName("java.sql.DriverManager");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sms");
                java.sql.Statement st=con.createStatement();
                String sql="select * from info";
                java.sql.ResultSet rs= st.executeQuery(sql);
                while(rs.next()){
                    jComboBox2.addItem(rs.getString(6));
                }
            }
            catch (Exception e) {
            
            }
    }
    final void print(){
        try {
                Class.forName("java.sql.DriverManager");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sms");
                java.sql.Statement st=con.createStatement();
                String sql="select * from "+Admin.course;
                java.sql.ResultSet rs= st.executeQuery(sql);
                while(rs.next()){
                    if(rs.getString(1).equals(sel)){
                        mid1.setText(rs.getString(2));
                        mid2.setText(rs.getString(3));
                        assig.setText(rs.getString(4));
                        proj.setText(rs.getString(5));
                        quiz.setText(rs.getString(6));
                        fnl.setText(rs.getString(7));
                    }
                }
            }
            catch (Exception e) {
            
            }
    }
    final void add(){
            try {
                Class.forName("java.sql.DriverManager");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sms");
                PreparedStatement ps = con.prepareStatement("UPDATE "+Admin.course+" SET mid1= ? WHERE rolllno= ?");
                ps.setObject(1, mid1.getText()); 
                ps.setString(2, sel);
                ps.executeUpdate();
                ps = con.prepareStatement("UPDATE "+Admin.course+" SET mid2 = ? WHERE rolllno = ?");
                ps.setObject(1, mid2.getText()); 
                ps.setString(2, sel);
                ps = con.prepareStatement("UPDATE "+Admin.course+" SET assigment = ? WHERE rolllno = ?");
                ps.setObject(1, assig.getText()); 
                ps.setString(2, sel);
                ps.executeUpdate();
                ps = con.prepareStatement("UPDATE "+Admin.course+" SET project = ? WHERE rolllno = ?");
                ps.setObject(1, proj.getText()); 
                ps.setString(2, sel);
                ps.executeUpdate();
                ps = con.prepareStatement("UPDATE "+Admin.course+" SET quiz = ? WHERE rolllno = ?");
                ps.setObject(1, quiz.getText()); 
                ps.setString(2, sel);
                ps.executeUpdate();
                ps = con.prepareStatement("UPDATE "+Admin.course+" SET final = ? WHERE rolllno = ?");
                ps.setObject(1, fnl.getText()); 
                ps.setString(2, sel);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, sel+" marks updated");
            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
    }
    /**
     * Creates new form Home
     */
    public AddMark() {
        initComponents();
        init();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        home = new rojeru_san.complementos.RSButtonHover();
        info = new rojeru_san.complementos.RSButtonHover();
        attendance = new rojeru_san.complementos.RSButtonHover();
        mark = new rojeru_san.complementos.RSButtonHover();
        gpa = new rojeru_san.complementos.RSButtonHover();
        rSButtonHover10 = new rojeru_san.complementos.RSButtonHover();
        logout = new rojeru_san.complementos.RSButtonHover();
        rSButtonHover11 = new rojeru_san.complementos.RSButtonHover();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        f = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        m2 = new javax.swing.JLabel();
        a = new javax.swing.JLabel();
        p = new javax.swing.JLabel();
        quiz1 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        m1 = new javax.swing.JLabel();
        tmid1 = new javax.swing.JLabel();
        tmid2 = new javax.swing.JLabel();
        tassig = new javax.swing.JLabel();
        tproj = new javax.swing.JLabel();
        tquiz = new javax.swing.JLabel();
        tfinal = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        rSButtonHover1 = new rojeru_san.complementos.RSButtonHover();
        jLabel5 = new javax.swing.JLabel();
        fnl = new javax.swing.JTextField();
        mid1 = new javax.swing.JTextField();
        mid2 = new javax.swing.JTextField();
        assig = new javax.swing.JTextField();
        proj = new javax.swing.JTextField();
        quiz = new javax.swing.JTextField();
        logout1 = new rojeru_san.complementos.RSButtonHover();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/apprentice.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 210, -1));

        home.setBackground(new java.awt.Color(51, 51, 51));
        home.setBorder(null);
        home.setText("Home");
        home.setColorHover(new java.awt.Color(204, 102, 0));
        home.setColorTextHover(new java.awt.Color(51, 51, 51));
        home.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
        });
        jPanel2.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 300, 50));

        info.setBackground(new java.awt.Color(51, 51, 51));
        info.setBorder(null);
        info.setText("All Student");
        info.setColorHover(new java.awt.Color(204, 102, 0));
        info.setColorTextHover(new java.awt.Color(51, 51, 51));
        info.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        info.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                infoMouseClicked(evt);
            }
        });
        jPanel2.add(info, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 300, 50));

        attendance.setBackground(new java.awt.Color(51, 51, 51));
        attendance.setBorder(null);
        attendance.setText("Add Student");
        attendance.setColorHover(new java.awt.Color(204, 102, 0));
        attendance.setColorTextHover(new java.awt.Color(51, 51, 51));
        attendance.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        attendance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                attendanceMouseClicked(evt);
            }
        });
        jPanel2.add(attendance, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 300, 50));

        mark.setBackground(new java.awt.Color(51, 51, 51));
        mark.setBorder(null);
        mark.setText("Add Marks");
        mark.setColorHover(new java.awt.Color(204, 102, 0));
        mark.setColorTextHover(new java.awt.Color(51, 51, 51));
        mark.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        mark.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                markMouseClicked(evt);
            }
        });
        mark.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                markActionPerformed(evt);
            }
        });
        jPanel2.add(mark, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 300, 50));

        gpa.setBackground(new java.awt.Color(51, 51, 51));
        gpa.setBorder(null);
        gpa.setText("Add GPA");
        gpa.setColorHover(new java.awt.Color(204, 102, 0));
        gpa.setColorTextHover(new java.awt.Color(51, 51, 51));
        gpa.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        gpa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gpaMouseClicked(evt);
            }
        });
        gpa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gpaActionPerformed(evt);
            }
        });
        jPanel2.add(gpa, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 430, 300, 50));

        rSButtonHover10.setBackground(new java.awt.Color(51, 51, 51));
        rSButtonHover10.setBorder(null);
        rSButtonHover10.setText("Remove Student");
        rSButtonHover10.setColorHover(new java.awt.Color(204, 102, 0));
        rSButtonHover10.setColorTextHover(new java.awt.Color(51, 51, 51));
        rSButtonHover10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        rSButtonHover10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover10MouseClicked(evt);
            }
        });
        jPanel2.add(rSButtonHover10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 550, 300, 50));

        logout.setBackground(new java.awt.Color(51, 51, 51));
        logout.setBorder(null);
        logout.setText("Log out");
        logout.setColorHover(new java.awt.Color(204, 102, 0));
        logout.setColorTextHover(new java.awt.Color(51, 51, 51));
        logout.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
        });
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        jPanel2.add(logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 640, 150, 50));

        rSButtonHover11.setBackground(new java.awt.Color(51, 51, 51));
        rSButtonHover11.setBorder(null);
        rSButtonHover11.setText("Add Attendance");
        rSButtonHover11.setColorHover(new java.awt.Color(204, 102, 0));
        rSButtonHover11.setColorTextHover(new java.awt.Color(51, 51, 51));
        rSButtonHover11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        rSButtonHover11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover11MouseClicked(evt);
            }
        });
        rSButtonHover11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover11ActionPerformed(evt);
            }
        });
        jPanel2.add(rSButtonHover11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 300, 50));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 700));

        jPanel1.setBackground(new java.awt.Color(204, 102, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Total");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 190, 210, 50));

        jComboBox2.setBackground(new java.awt.Color(204, 102, 0));
        jComboBox2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "none" }));
        jComboBox2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jComboBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox2ItemStateChanged(evt);
            }
        });
        jPanel1.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 70, 190, 40));

        f.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        f.setForeground(new java.awt.Color(255, 255, 255));
        f.setText("Final:");
        jPanel1.add(f, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 550, 150, 50));

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Obtained");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, 190, 50));

        m2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        m2.setForeground(new java.awt.Color(255, 255, 255));
        m2.setText("Mid 2:");
        jPanel1.add(m2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 150, 50));

        a.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        a.setForeground(new java.awt.Color(255, 255, 255));
        a.setText("Assigment:");
        jPanel1.add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 370, 150, 50));

        p.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        p.setForeground(new java.awt.Color(255, 255, 255));
        p.setText("Project:");
        jPanel1.add(p, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 430, 150, 50));

        quiz1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        quiz1.setForeground(new java.awt.Color(255, 255, 255));
        quiz1.setText("Quiz:");
        jPanel1.add(quiz1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 490, 150, 50));

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 10, 410));

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 190, 10, 410));

        jPanel11.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, 660, 10));

        jPanel12.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, 640, 10));

        jPanel13.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, 10, 410));

        jPanel14.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, 640, 10));

        jPanel16.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 540, 640, 10));

        jPanel17.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, 650, 10));

        jPanel18.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 420, 640, 10));

        jPanel19.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 360, 640, 10));

        jPanel20.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 190, 10, 410));

        m1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        m1.setForeground(new java.awt.Color(255, 255, 255));
        m1.setText("Mid 1:");
        jPanel1.add(m1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, 150, 50));

        tmid1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tmid1.setForeground(new java.awt.Color(255, 255, 255));
        tmid1.setText("15");
        jPanel1.add(tmid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 250, 220, 50));

        tmid2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tmid2.setForeground(new java.awt.Color(255, 255, 255));
        tmid2.setText("15");
        jPanel1.add(tmid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 310, 220, 50));

        tassig.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tassig.setForeground(new java.awt.Color(255, 255, 255));
        tassig.setText("5");
        jPanel1.add(tassig, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 370, 220, 50));

        tproj.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tproj.setForeground(new java.awt.Color(255, 255, 255));
        tproj.setText("10");
        jPanel1.add(tproj, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 430, 220, 50));

        tquiz.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tquiz.setForeground(new java.awt.Color(255, 255, 255));
        tquiz.setText("5");
        jPanel1.add(tquiz, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 490, 220, 50));

        tfinal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tfinal.setForeground(new java.awt.Color(255, 255, 255));
        tfinal.setText("50");
        jPanel1.add(tfinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 550, 220, 50));

        jPanel21.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 600, 660, 10));

        rSButtonHover1.setBackground(new java.awt.Color(204, 102, 0));
        rSButtonHover1.setText("X");
        rSButtonHover1.setColorHover(new java.awt.Color(204, 102, 0));
        rSButtonHover1.setColorTextHover(new java.awt.Color(255, 51, 51));
        rSButtonHover1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover1MouseClicked(evt);
            }
        });
        jPanel1.add(rSButtonHover1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 0, 40, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Student ID:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, 130, 40));

        fnl.setBackground(new java.awt.Color(204, 102, 0));
        fnl.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        fnl.setForeground(new java.awt.Color(255, 255, 255));
        fnl.setText("0");
        fnl.setBorder(null);
        jPanel1.add(fnl, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 550, 220, 50));

        mid1.setBackground(new java.awt.Color(204, 102, 0));
        mid1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        mid1.setForeground(new java.awt.Color(255, 255, 255));
        mid1.setText("0");
        mid1.setBorder(null);
        jPanel1.add(mid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 250, 220, 50));

        mid2.setBackground(new java.awt.Color(204, 102, 0));
        mid2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        mid2.setForeground(new java.awt.Color(255, 255, 255));
        mid2.setText("0");
        mid2.setBorder(null);
        mid2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mid2ActionPerformed(evt);
            }
        });
        jPanel1.add(mid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 310, 220, 50));

        assig.setBackground(new java.awt.Color(204, 102, 0));
        assig.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        assig.setForeground(new java.awt.Color(255, 255, 255));
        assig.setText("0");
        assig.setBorder(null);
        jPanel1.add(assig, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 370, 220, 50));

        proj.setBackground(new java.awt.Color(204, 102, 0));
        proj.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        proj.setForeground(new java.awt.Color(255, 255, 255));
        proj.setText("0");
        proj.setBorder(null);
        jPanel1.add(proj, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 430, 220, 50));

        quiz.setBackground(new java.awt.Color(204, 102, 0));
        quiz.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        quiz.setForeground(new java.awt.Color(255, 255, 255));
        quiz.setText("0");
        quiz.setBorder(null);
        jPanel1.add(quiz, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 490, 220, 50));

        logout1.setBackground(new java.awt.Color(51, 51, 51));
        logout1.setBorder(null);
        logout1.setText("Add");
        logout1.setColorHover(new java.awt.Color(204, 102, 0));
        logout1.setColorTextHover(new java.awt.Color(51, 51, 51));
        logout1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        logout1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout1MouseClicked(evt);
            }
        });
        jPanel1.add(logout1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 630, 150, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, 900, 700));

        setSize(new java.awt.Dimension(1200, 700));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        // TODO add your handling code here:
        dispose();
        new AdminHome().show();
    }//GEN-LAST:event_homeMouseClicked

    private void infoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_infoMouseClicked
        // TODO add your handling code here:
        dispose();
        new Student().show();
    }//GEN-LAST:event_infoMouseClicked

    private void attendanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_attendanceMouseClicked
        // TODO add your handling code here:
        dispose();
        new AddStudent().show();
    }//GEN-LAST:event_attendanceMouseClicked

    private void markMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_markMouseClicked
        // TODO add your handling code here:
        dispose();
        new AddMark().show();
    }//GEN-LAST:event_markMouseClicked

    private void gpaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gpaMouseClicked
        // TODO add your handling code here:
        dispose();
        new AddGpa().show();
    }//GEN-LAST:event_gpaMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        // TODO add your handling code here:
        dispose();
        new Login().show();
    }//GEN-LAST:event_logoutMouseClicked

    private void jComboBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox2ItemStateChanged
        // TODO add your handling code here:
        sel=(String) jComboBox2.getSelectedItem();
        print();
    }//GEN-LAST:event_jComboBox2ItemStateChanged

    private void rSButtonHover1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover1MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_rSButtonHover1MouseClicked

    private void mid2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mid2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mid2ActionPerformed

    private void logout1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout1MouseClicked
        // TODO add your handling code here:
        if(valid()){
            add();
        }
    }//GEN-LAST:event_logout1MouseClicked

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_logoutActionPerformed

    private void gpaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gpaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gpaActionPerformed

    private void rSButtonHover10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover10MouseClicked
        // TODO add your handling code here:
        dispose();
        new remove().show();
    }//GEN-LAST:event_rSButtonHover10MouseClicked

    private void rSButtonHover11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover11MouseClicked
        // TODO add your handling code here:
        dispose();
        new addAtten().show();
    }//GEN-LAST:event_rSButtonHover11MouseClicked

    private void rSButtonHover11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSButtonHover11ActionPerformed

    private void markActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_markActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_markActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel a;
    private javax.swing.JTextField assig;
    private rojeru_san.complementos.RSButtonHover attendance;
    private javax.swing.JLabel f;
    private javax.swing.JTextField fnl;
    private rojeru_san.complementos.RSButtonHover gpa;
    private rojeru_san.complementos.RSButtonHover home;
    private rojeru_san.complementos.RSButtonHover info;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel9;
    private rojeru_san.complementos.RSButtonHover logout;
    private rojeru_san.complementos.RSButtonHover logout1;
    private javax.swing.JLabel m1;
    private javax.swing.JLabel m2;
    private rojeru_san.complementos.RSButtonHover mark;
    private javax.swing.JTextField mid1;
    private javax.swing.JTextField mid2;
    private javax.swing.JLabel p;
    private javax.swing.JTextField proj;
    private javax.swing.JTextField quiz;
    private javax.swing.JLabel quiz1;
    private rojeru_san.complementos.RSButtonHover rSButtonHover1;
    private rojeru_san.complementos.RSButtonHover rSButtonHover10;
    private rojeru_san.complementos.RSButtonHover rSButtonHover11;
    private javax.swing.JLabel tassig;
    private javax.swing.JLabel tfinal;
    private javax.swing.JLabel tmid1;
    private javax.swing.JLabel tmid2;
    private javax.swing.JLabel tproj;
    private javax.swing.JLabel tquiz;
    // End of variables declaration//GEN-END:variables
}
